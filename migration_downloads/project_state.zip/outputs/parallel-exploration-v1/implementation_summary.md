# 本轮实施与运行结果

- 候选458条：{'B': 428, 'C': 30}；开发313条：{'B': 283, 'C': 30}；历史留出145条。
- 候选涉及29个论文文件名，匹配到当前本地PDF 8个；其余逐项见paper_availability.json，不因未匹配就阻断全部建模。
- 28组实验，8344条折外预测记录；98项测试通过，原始Excel和输入版本哈希全部不变。
- 主要模型：AB__materials__median__xgb__unknown；MAE 5.7187、RMSE 8.6963 MPa、R² 0.4312。
- 各来源组等权平均MAE 9.4956 MPa，最差来源组MAE 45.4717 MPa。不能仅看合并样本分数。
- 同样B级验证样本：材料+中位数XGBoost加入C级训练样本后MAE从5.7187变成6.0413 MPa，暂未显示收益。该比较是一次固定划分结果，不作显著性结论。
- 训练折全未知列产生数值警告，插补后预测均为有限值，验证通过。下一版可显式处理全未知列以减少日志噪声，无需删除样本。
- 已有折外置换重要性、283条折外SHAP、逐论文误差及Excel汇总。SHAP中缺失标记也有贡献，可能反映论文记录习惯，需关注迁移风险。
- 原始测量强度并非全部逐项核实，换算仍为0.95/0.8/0.76暂定规则；本次B级不是正式可信资格。未给未入选的其他624条记录强行分级或伪造标签。
- 部分材料原表量纲和绝对用量依据仍待核查；外加剂14字段只作敏感性。旧严格128条实验与本次283条不同，不能直接把分数差异解释为方法提升。
- 下一轮先做内层分组调参、无量纲配合比特征、CatBoost/SVR/MLP对照；文献轨道同步优先核查高误差且多样本来源，保留可信高强度样本。

修改/新增代码与说明文件：

- configs/parallel_exploration_v1.json
- src/concrete_audit/parallel_exploration.py
- scripts/run_parallel_exploration.py
- scripts/explain_parallel_exploration.py
- scripts/summarize_parallel_research.py
- tests/test_parallel_exploration.py
- requirements-exploration.txt
- docs/parallel_research_plan.md
- README.md

关键函数：feature_matrix解析输入和零值策略；quality保留正式状态并生成研究分层；allocate隔离论文与重复配合比；make_pipeline确保训练折内预处理；run运行统一外层分组对照；explain解释折外预测；summarize重新核对结果。
