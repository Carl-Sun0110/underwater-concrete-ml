# 双轨探索基线报告

本报告全部为探索性结果；原始标签按用户许可暂定系数换算，不代表正式可信数据库。
候选458条，开发313条，历史留出145条；开发等级{'B': 283, 'C': 30}。
同一套来源分组五折；AB与ABC使用共同的分组折，shared_AB_metrics可用于相同AB验证样本上的比较。
中位数和标准化KNN插补均限训练折。保留所有有有效标签的开发记录，不按缺失率或高强度删样本。
材料零值默认未知；零值照录另做敏感性实验。SP/AWA混合单位只做探索对照，不能作可迁移物理定量解释。

|实验|n|MAE MPa|RMSE MPa|R²|论文组平均MAE|
|---|---:|---:|---:|---:|---:|
|AB__core__median__mean__unknown|283|7.527|11.850|-0.056|12.092|
|AB__core__median__rf__unknown|283|8.010|10.366|0.192|9.876|
|AB__core__median__xgb__unknown|283|6.086|9.609|0.306|9.639|
|AB__core__knn__rf__unknown|283|7.390|9.937|0.257|9.143|
|AB__core__knn__xgb__unknown|283|6.071|9.566|0.312|9.493|
|AB__materials__median__rf__unknown|283|7.107|10.323|0.198|10.825|
|AB__materials__median__xgb__unknown|283|5.719|8.696|0.431|9.496|
|AB__materials__knn__rf__unknown|283|7.739|10.963|0.096|11.419|
|AB__materials__knn__xgb__unknown|283|6.061|9.307|0.349|9.472|
|AB__admixtures_sensitivity__median__rf__unknown|283|6.325|10.397|0.187|10.471|
|AB__admixtures_sensitivity__median__xgb__unknown|283|5.678|9.095|0.378|9.125|
|AB__admixtures_sensitivity__knn__rf__unknown|283|6.824|10.213|0.216|10.376|
|AB__admixtures_sensitivity__knn__xgb__unknown|283|5.522|8.990|0.392|8.824|
|AB__admixtures_sensitivity__median__rf__recorded|283|6.681|10.664|0.145|10.790|
|ABC__core__median__mean__unknown|313|7.775|11.802|-0.069|11.907|
|ABC__core__median__rf__unknown|313|7.620|9.967|0.238|9.398|
|ABC__core__median__xgb__unknown|313|6.219|9.554|0.299|9.542|
|ABC__core__knn__rf__unknown|313|7.150|9.750|0.270|8.639|
|ABC__core__knn__xgb__unknown|313|6.085|9.477|0.311|9.359|
|ABC__materials__median__rf__unknown|313|6.847|10.260|0.192|10.683|
|ABC__materials__median__xgb__unknown|313|6.145|8.728|0.415|9.077|
|ABC__materials__knn__rf__unknown|313|7.513|10.718|0.118|11.263|
|ABC__materials__knn__xgb__unknown|313|6.047|9.271|0.340|8.838|
|ABC__admixtures_sensitivity__median__rf__unknown|313|6.805|10.349|0.178|10.636|
|ABC__admixtures_sensitivity__median__xgb__unknown|313|6.312|9.281|0.339|9.317|
|ABC__admixtures_sensitivity__knn__rf__unknown|313|6.535|9.916|0.245|10.204|
|ABC__admixtures_sensitivity__knn__xgb__unknown|313|6.234|9.491|0.309|9.279|
|ABC__admixtures_sensitivity__median__rf__recorded|313|6.617|10.308|0.184|10.880|

主要候选（不含混合单位外加剂）最低CV MAE：AB__materials__median__xgb__unknown。
已保存折外误差、核查优先记录、验证折置换重要性及开发集拟合模型。选模后的CV分数有选择偏差；尚无新独立测试结论。
下一轮：针对最高折外误差论文核查单位/范围，补充无量纲配合比；内层分组调参，再做版本间同折比较。
