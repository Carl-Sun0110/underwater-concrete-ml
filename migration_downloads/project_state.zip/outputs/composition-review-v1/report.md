# 胶凝材料、纤维和原文材料家族核查

范围：现有严格训练128条、5个独立来源组；未按误差删样本，未重新训练或使用145条测试。全部比例为独立候选诊断，不自动授予可信资格或加入模型。

## 原文声明家族与来源完全混杂

|原文声明家族|训练记录|独立来源组|
|---|---:|---:|
|ECCUWC|6|1|
|SPUC|104|1|
|UN-UHPC|4|1|
|self-flowing underwater concrete|11|1|
|underwater repair concrete|3|1|

这些是原文自述的家族/用途标签，并非互斥的通用材料分类。本训练集每类仅1组；按来源留组时，每个验证记录的家族在该训练折都未见过。直接编码标签不能证明跨材料体系预测能力，也不能用强度阈值反推体系标签。

## 组分证据覆盖

|候选比例|有值/128|独立来源组|
|---|---:|---:|
|fa_to_cement_mass_ratio|16|3|
|sf_to_cement_mass_ratio|7|2|
|ggbs_to_cement_mass_ratio|4|1|
|steel_to_cement_mass_ratio|4|1|
|pva_to_cement_mass_ratio|6|1|
|pp_to_cement_mass_ratio|1|1|
|cement_fraction_from_defined_reported_components|11|3|
|water_over_defined_reported_binder_components|10|2|

FA、SF、GGBS及钢/PVA/PP纤维分别保留；未将未报告、原表横线或其他纤维类型都填0。纤维质量比不等于体积分数，也不表示不同纤维效果相同。

## 胶材分母与水量单位

只有11条能对已定义且各项明确的原文胶材组分求完整和；其余不把缺项当0。
Zhang四条：原文归一化胶材1+.06+.18+.19=1.43，按报告组分计算水胶比.223/1.43≈0.15594；不因此核实原库kg/m³基准。
Al-Selmi六条：分项1202+301=1503，而原文表注1502；保存两个数值及冲突标记。605/1503≈0.40253只是按分项定义计算的候选，不擅自选定正确总量或直接用于训练。
Yousri仅M-0.5-10FA-5SF一条在Cem/FA/SF三列都为明确正值，可对这一定义求和592；其他行的横线保持未知，不强行统一胶材总量。
Yousri11条、Brzozowski3条共14条，原文Water列单位为L/m³。当前历史核心输入虽按质量使用，本模块不以数值相同证明kg/m³转换，不自动假定水密度；新的水胶比不跨单位计算。原Water及历史模型不回写。

## 当前处理与下一步

暂不把这些稀疏/有定义疑点的字段直接加进模型。先完成原表横线是否代表未掺的字段级核查、胶材定义与单位绑定，再确定预先声明的特征敏感性方案；家族标签保持诊断用途。当前来源数量不支持按每个家族各自建立可泛化模型。
没有通过删除UHPC/ECC记录来追求更高R²，未做目标驱动的材料分类，也不再扩大参数搜索。

关键函数：complete_component_sum对任何未知组分返回未知；derive_composition分开保存分项和、原文总量与候选比例；family_confounding检查家族在各来源折中的可见性。

输出：composition_records.json、field_coverage.json、family_confounding.json、feature_policy.json及独立Excel；证据均重新与实际PDF页码/摘录和版本校验。
