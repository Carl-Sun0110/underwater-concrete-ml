# 新上传三篇原文核查报告

核查134条：Nasr静水40条、Nasr流动水64条、Assaad30条，均在既有训练部分。按来源定向核查，不据此估计全库通过率。

134条原库CS_28d均与对应原表的实测强度数字一致。Nasr明确选择28d FW/SW列；Assaad按原库CastMethod对应冲洗/渗水分支，未用目标值反推列位。没有用空气强度、相对强度或回归式替代目标。

**数字匹配不是整条可靠性批准。新增“已核实可用”样本仍为0。**

## 必须保留的问题

- Assaad30条：§3.4.3为冲洗或渗水后回收、重新装入100×200mm圆柱，再养护至28天。与严格水下浇筑范围不同，建议后续主分析隔离；不删除、不覆盖当前数据，也未更改既有划分或可靠状态。
- 两篇Nasr的UPA加在外部水环境，不是混凝土内掺AWA。按原表保存水体浓度%，质量/体积定义仍未知，不换算成AWA kg/m³。
- 两篇材料段均出现0.05%，C2配比表及配比段给0.005%；涉及38条C2记录。分开保留矛盾，不擅自宣布哪个数字正确。
- Nasr静水Table1中SP单位L/100kg水泥，正文§3.4写kg/100kg水泥。40条质量SP继续待核；不通过猜测产品密度去证明原库kg/m³。
- Assaad缓凝剂为UWC水泥质量的0.6%，CEM砂浆为0.4%；30条独立质量候选计算均保留参数来源，未回写原库0。
- Assaad AWA/HRWR按原文“% of cement”记录；原表横线不转成零，UWC与CEM列不混用。
- 静水表2印刷配方5M2C1/6M3C1按已审查的明确别名映射到M2C1/M3C1，保留印刷ID；没有普遍删除数字或模糊匹配。
- 用户允许的0.95、0.8、0.76仍只是暂定换算规则；本轮未把实测值匹配当作换算系数或“无密度假设”的证明。

## 实际运行结果

字段核查1790项，其中1284项有定位证据，506项本轮未编录。辅助状态：956数值/规格等一致、30需转换、298待人工确认、506证据不足；所有记录均需人工最终确认。未编录不表示原文没有报告。

材料候选层累计242条有至少一项定位声明，共1245项声明（此前108条/447项）；这些不是完整可用样本数。当前训练部分至少一项候选覆盖158/299条，17篇未匹配训练原文减少至14篇。没有一项新增材料字段完整覆盖299条，不能整体补0入模。

完整65项测试通过。核查配置、原始Excel、批注版、可靠状态档案、暂定标签、划分和论文输入均通过内容指纹复核。两篇Nasr仍在同一防泄漏组。本轮不训练、不重新评价测试集。

## 输出及复现

- `outputs/three-paper-review-v1/三篇原文核查摘要.xlsx`：134条简表和关键问题。
- `outputs/three-paper-field-check-v2/小批字段核查.xlsx`：1790项详细字段核查及证据。
- `outputs/material-feature-three-papers-v1/材料字段与证据.xlsx`：458条独立候选视图及累计证据。
- `source_issues.json`、`protocol_scope_proposals.json`、`strict_casting_scope_proposal.json`：疑点和30条范围隔离建议，均未变更原档案。
- `validation.json`、`tests.log`：实跑结果。

```bash
python scripts/prepare_three_paper_review.py
PYTHONPATH=src python -c 'from concrete_audit.field_review import run; run("configs/three_paper_field_evidence.json", "outputs/new-three-paper-check")'
python scripts/run_material_features.py --config configs/material_feature_evidence_three_papers.json --output outputs/new-three-paper-materials
PYTHONPATH=src /workspace/.venv-underwater-ml/bin/python -m unittest discover -s tests -v
```

编录脚本使用本轮保存的PDF提取文本；执行核查时会重新读取原PDF并校验引文与版本，文本匹配不自动证明人工解释正确。

## 本轮修改

新增`src/concrete_audit/source_tables.py`、`tests/test_source_tables.py`、`scripts/prepare_three_paper_review.py`、`scripts/summarize_three_paper_review.py`及两份新证据配置。扩展`material_features.py`、`test_material_features.py`，更新README/CHANGELOG。原文件及历史输出均保留。

下一步优先落实严格水下浇筑范围门禁和实验条件字段，再明确训练内敏感性方案。当前不急于追求更高R²，也不要求一次补齐剩余论文。
