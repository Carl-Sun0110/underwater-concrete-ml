# 五类算法与两篇文献复查

同一283条AB、20来源连通组、五外层折。新增SVR/MLP四组原始流水线和四组折内恒定列过滤对照；108项测试通过。
输入和目标缩放均只在内层训练折拟合；MLP采用Dropout=.15、固定150轮，未用外层标签早停。

|模型（材料特征）|MAE MPa|RMSE MPa|R²|来源组平均MAE|
|---|---:|---:|---:|---:|
|rf|6.862|10.156|0.224|10.837|
|xgb|5.892|8.740|0.425|9.357|
|catboost|6.524|10.302|0.202|11.171|
|svr|6.555|9.840|0.272|11.224|
|mlp|7.331|14.090|-0.493|12.070|

异常与修正：
- 原MLP材料流水线MAE52.114、R²-403.926；折内移除严格恒定列后MAE7.331、R²-0.493。原始失败结果完整保留。
- 原因证据：外层折1的MK/SS在训练中无变化，验证标准化值最高分别480和914.4；MLP未学习的输入连接可能被激活。移除恒定列显著缓解此问题，但不证明所有错误只由该机制导致。
- 剩余分布外输入、材料体系覆盖及样本来源不平衡仍存在。SVR加比值并过滤恒定列MAE6.392、RMSE10.671、R²0.144；不能只凭MAE认定所有指标都改善。
- 这项诊断修正在看到旧外层结果后提出，不能将其称为预注册或独立最终验证。训练折过滤不使用验证信息，但研究过程仍有适应性选择偏差。
- 本批模型均未超过此前固定参数XGBoost的MAE5.719；继续保留该模型作为探索参考，不宣称正式最优。

文献轨道：重新提取两篇原PDF指定页并复现两条不同配比引用，覆盖10条记录。Zhang按相对水泥质量归一化；Al-Selmi组分和1503与注释1502冲突仍保留。未修改原表、标签或正式可靠状态。

后续优先级：停止反复扩大同一开发集参数搜索；比较内层按来源组等权选参，补充同体系独立来源、完成优先字段核查后做数据版本同折对照。保留高强度记录，最终科研评价需另行预先确定独立验证方案。

修改/新增文件：configs/parallel_svr_mlp_v1.json、configs/parallel_svr_mlp_variance_v1.json、src/concrete_audit/neural_comparison.py、src/concrete_audit/scaled_comparison.py、scripts/run_svr_mlp.py、scripts/run_scaled_comparison.py、scripts/recheck_two_papers.py、scripts/summarize_complete_algorithms.py、tests/test_neural_comparison.py、tests/test_scaled_comparison.py、README.md、requirements-complete-models.txt。
函数说明：search_model处理训练折内输入/目标缩放及搜索；filtered_search追加折内恒定列过滤；recheck从原PDF复现引用；summarize重算指标并关联预测、单位和来源证据。
