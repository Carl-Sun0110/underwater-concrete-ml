# Water/Cem探索性基线结果

结论：流程已实际跑通，但两输入岭回归没有优于训练均值预测。不能据此宣称正式强度模型有效，也不能据此断言更完整特征/其他模型均无效。
标签仍为用户允许的0.95/0.8/0.76暂定换算，样本原可靠状态、密度及零值待核查标记均未提升。

## 数据与隔离

- 458条探索标签中，444条Water/Cem为正进入本次流程，另14条保留，不填补。
- 唯一输入为Water、Cem；目标、原始强度、换算系数、试件及来源标识不作为输入。
- 27个Research Group经来源和全配比签名保守关联形成26个防泄漏组；Nasr2022与Ahmed2022同组，不删除记录、不使用目标判重。
- 固定seed=42，一次按20%组数抽取测试，得到299条训练、145条测试，分别20/6组。分组比例不是行数比例，故测试行数约32.7%。
- 训练/测试的防泄漏组、Research Group、PDF身份均无交集。没有按分数尝试不同随机种子。
- 训练部分外层5折GroupKFold，岭回归每个外折内层4折调alpha，避免用外折结果选alpha；最终在全部训练部分5折调参。
- StandardScaler放在Pipeline内，每个训练折独立拟合，无填补器；最终测试不参与缩放或参数选择。
- alpha候选0.01、0.1、1、10、100、1000，按训练CV MAE选择，最终为1000。没有为提高测试成绩扩大搜索。

## 独立测试集结果（145条）

|模型|R²|MSE（MPa²）|RMSE（MPa）|MAE（MPa）|MAPE|
|---|---:|---:|---:|---:|---:|
|mean|-0.0035|114.465|10.699|9.225|36.95%|
|ridge|-0.0139|115.658|10.754|9.225|37.09%|

mean使用训练集均值，不使用测试集均值。R²为负表示在该测试集上未优于以测试均值定义的R²参照；两种模型的MAE几乎相同。
MAPE在小强度样本上较敏感；这里与MPa绝对误差一起报告，不单独用于判断优劣。

## 训练部分嵌套分组验证

|模型|汇总折外R²|RMSE（MPa）|MAE（MPa）|
|---|---:|---:|---:|
|mean|-0.1154|12.248|8.134|
|ridge|-0.2289|12.856|9.105|

这是299条训练记录的外层折外预测汇总，不是最终调参时的最佳折分数；各折与各测试来源结果单独保存。
结果支持“当前两特征基线预测改进不足”，但不能区分特征不足、来源差异、原始数据误差和暂定标签影响各自的贡献。

## 图像

![Test predictions](test_predictions.png)

![Test residuals](test_residuals.png)

均值预测呈水平线；高正则下岭回归也接近均值，不能充分区分高低强度。

## 可复现运行与验证

```bash
python scripts/run_baselines.py --output outputs/new-baseline-run
PYTHONPATH=src python -m unittest discover -s tests -v
```

- 本次6项新增测试，连同已有28项共34项通过，0失败。
- 外层5折均完成且验证记录总数299；444条预测完整、样本ID唯一。
- 检查来源组、论文、研究组均不跨训练/测试；所有输入及原始可信档案哈希未变。
- 运行期间修正Matplotlib只读缓存路径为/tmp；同配置重复执行的指标完全相同，未重选划分或调参规则。
- 所有实际运行均保留输出；v1与v2仅缓存配置修正，不因效果选择版本。
- 依赖已在环境安装，无需本轮安装；版本固定在requirements-modeling.txt并记录于manifest。

## 输出与代码

- metrics.json：嵌套CV、测试集5项指标、最终alpha和训练调参表。
- split_manifest.json：固定划分、来源关联与14条未进入训练的ID。
- cv_folds.json：外层折隔离、各折指标、内层调参表。
- predictions.csv / predictions.json：299条外层折外预测和145条测试预测。
- test_source_metrics.json：测试集中各论文来源表现，单样本/常量组的R²不伪造。
- mean_model.joblib / ridge_pipeline.joblib：探索基线对象，不作为部署或正式可信模型。
- test_predictions.png / test_residuals.png：结果图。
- 新增baselines.py、run_baselines.py、baseline_experiment.json、test_baselines.py、requirements-modeling.txt。

## 后续边界

后续应在训练部分比较可靠扩展特征及SVR/RF/XGBoost/MLP，先确定方案，再报告测试表现；不根据本次测试分数逐次挑特征或随机种子。
当前测试集已经查看，如反复据测试结果调整方案，最终结论需新的独立验证。
没有执行四算法建模、扩大样本真实性标准、补标签或自动提升可信状态。
