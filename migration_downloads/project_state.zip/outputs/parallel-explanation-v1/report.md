# 折外解释与核查重点

对主要候选AB__materials__median__xgb__unknown的283条折外预测进行Tree SHAP解释；最大加和残差0.00002289 MPa。

高误差论文（不是删除清单）：

- 2025-Yu Zhang-[Mechanism of Highly Adsorbent Macromolecular].pdf：n=4，MAE=45.47 MPa。
- 2024-Baizhi Wang-[Filling-performance-of-self-protecting-underwater].pdf：n=1，MAE=19.29 MPa。
- 2026-Zainab M. Al-Selmi-[Experimental-and-Statistical-Optimization-of-Engineered].pdf：n=6，MAE=14.75 MPa。
- 2023-Zhongzhe Zhang-[Effect-of-antiwashout-admixture-on-compressive-strength-of].pdf：n=8，MAE=11.25 MPa。
- 2015-Camille A. Issa-[Bond-of-tension-bars-in-underwater-concrete].pdf：n=5，MAE=10.56 MPa。

优先核查不同材料体系、配合比绝对用量/相对比例及标签换算适用性；已核实的高强度测量值不得为改善指标而删改。SHAP不能证明特征具有因果作用，也不能证明原始数据真实。
