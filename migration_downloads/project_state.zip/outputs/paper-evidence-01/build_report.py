"""记录本轮人工阅读的字段级证据；不修改可靠状态主档或任何输入。"""
from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment

ROOT=Path(__file__).resolve().parent
papers=json.loads((ROOT/'papers.json').read_text())
registry_path=ROOT.parent/'final-audit/registry.json'
registry_before=hashlib.sha256(registry_path.read_bytes()).hexdigest()
registry=json.loads(registry_path.read_text())
P={p['key']:p for p in papers}
# 每项结论只限所列字段/定位，不构成整条记录已核实。
findings=[
('Sonebi',3,'Materials；Mixing and test methods','试件及减水剂信息','100 x 200 mm cylinders；melamine HRWR: 1.20 specific gravity；naphthalene HRWR: 1.21 specific gravity',
 '可确认文中圆柱100×200 mm，减水剂按类型报告不同相对密度。','这些值不能移用于缓凝剂、纤维素AWA或混凝土整体；各记录外加剂类型仍需对应。','Cy100有原文支持；本轮未逐条复核强度及0.95换算系数来源。'),
('Sonebi',4,'Table 1；Mixing and test methods续','缓凝剂及配合比','Set retarder, mL/100 kg of cementitious materials: 85；主材料用量以kg/m³列出',
 '85是每100 kg胶材的缓凝剂体积，不是kg/m³；不能把现有0当作未掺。','所查材料及配合比段落未找到可直接用于缓凝剂质量换算的产品密度。','保留原值；在核查表标记缓凝剂质量未知，主材料表格值不等于整条特征已完整。'),
('Yousri',3,'Table 2；Experimental programme续','HRWR单位与特殊配方','HRWR l/m³: 2.1 / 2.5；M–10FA–VA中HRWR为横线；viscosity agent为0.6%',
 '减水剂表格单位为L/m³；M–10FA–VA不能套用2.5。','同页正文写0.35～0.42% by mass of cement，与逐行表格的单位及基准关系需要解释；本轮未获得可靠产品密度。','先逐配方核对，禁止把体积数字直接当质量；特殊配方独立处理。'),
('Yousri',3,'Experimental programme续','试件及养护','Twelve 150 mm cubes；cubes filled under water；tested at 3, 7 and 28 days',
 '150 mm立方体及水下/空气对照有明确说明。','本轮未逐条复核28d强度提取精度、零值和换算适用依据。','Cu150有原文支持，但整条可靠状态继续待核查。'),
('Wang',3,'§2.2；Table 3','绝对用量来源','water:binder=0.48；cement:sand:stone=1:1.8:2.3；UWB-II=1/40 of cement；Table 3: mass ratio',
 '表3给质量比例，所查段落未提供足以唯一还原各配方kg/m³的统一基准。','是否在原始提取过程中借助了假设密度仍未知；原文材料密度不能自动视为混凝土体积基准。','19条继续暂不纳入候选；不能宣称已证明使用或未使用密度假设。'),
('Wang',4,'Fig.4；§2.3续；§2.4.2','浇筑与试件','Fig.4: forming ... samples for compression testing；100 mm × 100 mm × 100 mm cubic molds',
 '图4给出水中灌注示意，正文明确100 mm立方体。','需继续核对各样本目标读数、配比绝对用量及统一换算依据。','水下成型有图示支持，但不得据此恢复19条为可信样本。'),
('Brzozowski',2,'§2.1；§2.2.1','正文密度信息与试件','superplasticizer ... specific weight of 1.16 kg/m³ ... 2% of cement mass；100 mm cubes',
 '原文确有减水剂specific weight数值，不能再简单记为“完全未报告密度”；单位按印刷原文为kg/m³。','印刷单位异常；不能擅自改成kg/L。正文2%×429=8.58 kg/m³，不能直接与表1的12 L/m³等同。','标为原文单位/掺量冲突；100 mm切割立方体有原文支持。'),
('Brzozowski',3,'Table 1','SP及乳液体积','UCR1/UCR2 superplasticizer=12.0 L/m³；UCR3=6.0 L/m³；UCR3 styrene-acrylic co-polymer=5 L/m³',
 '表1明确减水剂及乳液为体积用量。','正文异常单位和质量百分比与表格冲突未解决；未找到乳液可靠质量换算依据。','保留SP和乳液原值待核；不直接录为12、6、5 kg/m³。'),
('Chaikasatsin',53,'§4.2.3.3；Fig.4.2（印刷页38）','静态离析试件','Cast concrete cylinder specimens (150 x 300 mm) and split ...',
 '150×300 mm在静态离析试验中出现。','不能自动挪用为抗压试件尺寸。','505～510行的默认Cy150不能写成论文已明确报告的抗压尺寸。'),
('Chaikasatsin',54,'§4.2.3.5（印刷页39）','抗压方法','Compressive strength ... ASTM C39；specimens both underwater and in the air；7, 14, 28 days',
 '抗压章节说明ASTM C39、环境对照及龄期。','该段没有给对应抗压圆柱直径和高度。','规格依据继续待核查；标准名称不能代替尺寸证据。'),
('Chaikasatsin',60,'Table 4.3（印刷页45）；PDF p50 §4.1','最终修补配方','w/b=0.40；Sp/b=2.5%；VMA/w=7%；rfa=10%；Exp.=30 kg；p50正文为30 kg/m³ expansive agent',
 '配比表给出比例、掺量及单位说明；正文另支持膨胀剂30 kg/m³。','表4.3仍未直接列出该最终配方所有组分完整kg/m³；不能凭比例填补其余零值。','509～510行逐字段待核，避免把全部0解释成未添加。'),
('Chaikasatsin',72,'Table 5.1；§5.3.1.1（印刷页57）','顶管干硬性混凝土','dry-cast concrete for jacking pipe；Gravel 356+830 kg/m³；SP 3140/3100 mL/m³',
 '表格属于顶管干硬性混凝土，且减水剂另用mL/m³。','511～513行是否符合本阶段水下浇筑范围需要重新核对；强度与规格尚未逐条解决。','不能仅因论文含水下混凝土章节就将该章配方视作水下浇筑；本轮不删除记录。'),
]
headers=['证据ID','论文','PDF页码','定位','涉及字段','原文摘录','本轮可确认事实','未知或冲突','处理建议','整条可靠状态','PDF_SHA256']
rows=[]
for i,f in enumerate(findings,1):
 key,page,loc,field,quote,fact,unknown,action=f
 rows.append(dict(zip(headers,[f'E{i:02}',key,page,loc,field,quote,fact,unknown,action,'待核查（字段证据不升级整条）',P[key]['sha256']])))
links=[]
for key,paper in P.items():
 year={'Sonebi':'2001','Yousri':'2008','Wang':'2021','Brzozowski':'2021','Chaikasatsin':'2020'}[key]
 selected=[r for r in registry if key in (r['pdf_filename'] or '') and year in r['pdf_filename']]
 for r in selected:
  links.append({'论文':key,'record_id':r['record_id'],'原表行号':r['source_row'],
                '原PDF文件名':r['pdf_filename'],'实际上传PDF':paper['path'],
                '样本ID':r['specimen_id'],'浇筑环境':r['casting_env'],'初筛候选':r['candidate_link'],
                '当前状态':r['status'],'关联方式':'作者/年份/题名与内容对应；(1)视为上传文件名后缀，不证明不同文件版本完全一致',
                '核查范围':'本轮为来源级问题核查，非逐条全字段核实'})
workbook=openpyxl.Workbook();workbook.remove(workbook.active)
def add(name,data):
 sheet=workbook.create_sheet(name)
 keys=list(data[0]) if data else ['无记录'];sheet.append(keys)
 for item in data:sheet.append([str(item.get(k,'')) if isinstance(item.get(k), (list,dict)) else item.get(k) for k in keys])
 sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
 for c in sheet[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='315A74')
 for col in sheet.columns:
  letter=col[0].column_letter;sheet.column_dimensions[letter].width= min(65,max(14,len(str(col[0].value))*2+2))
 for row in sheet.iter_rows(min_row=2):
  sheet.row_dimensions[row[0].row].height=80
  for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
add('字段证据核查',rows);add('相关记录索引',links)
add('来源文件',[{'论文':p['key'],'文件':p['path'],'SHA256':p['sha256'],'PDF页数':p['pages']} for p in papers])
add('使用说明',[{'事项':'范围','说明':'本轮仅核查5篇论文的指定问题，不代表全文逐记录验证或最终可信数据集。'},
               {'事项':'原始数据','说明':'所有PDF与Excel只读；可靠状态主档未修改；候选与待核查标签原样保留。'},
               {'事项':'页码','说明':'页码以PDF文件从第一页起计，括号内印刷页码仅作辅助。'},
               {'事项':'核查结论','说明':'由本次助手阅读指定原文得到的字段级证据摘要，尚未经用户/老师复核签字。'},
               {'事项':'后续','说明':'优先审阅单位冲突和规格依据，再补产品资料或历史提取记录；不默认填补或训练。'}])
workbook.save(ROOT/'第一批论文_字段证据核查.xlsx')
(ROOT/'findings.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
(ROOT/'record_links.json').write_text(json.dumps(links,ensure_ascii=False,indent=2))
lines=['# 第一批论文证据核查','', '本次只核查此前列出的关键问题，未修改原始Excel/PDF、可靠状态主档或候选资格；未训练模型。',
       'PDF页码从文件第一页起计。字段级证据不等于整条样本已核实；以下结论尚待用户或老师审阅。','',
       '## 实际关联范围','', '|论文|当前主表相关记录|其中初筛候选|','|---|---:|---:|']
for key in P:
 selected=[r for r in links if r['论文']==key];lines.append(f'|{key}|{len(selected)}|{sum(r["初筛候选"] for r in selected)}|')
lines += ['', '以上是当前档案的实际记录数，包含空气对照及候选外记录，不是新增可信数量。',
          '文件名中的(1)单独保留，未重命名原文件；关联是来源身份对应，不能证明与历史提取时PDF字节完全一致。','',
          '## 主要核查结果','']
for row in rows:
 lines += [f'### {row["证据ID"]} {row["论文"]}：{row["涉及字段"]}', '',
           f'位置：PDF第{row["PDF页码"]}页，{row["定位"]}。',
           f'原文摘录：{row["原文摘录"]}',f'可确认：{row["本轮可确认事实"]}',
           f'未解决：{row["未知或冲突"]}',f'建议：{row["处理建议"]}','']
lines+=['## 下一步','',
        '1. 审阅Excel“字段证据核查”页，尤其Brzozowski正文specific weight单位与表格冲突。',
        '2. 有条件时补Yousri的减水剂和Sonebi缓凝剂产品资料，优先寻找对应产品、年代、密度和剂量基准。没有资料继续未知。',
        '3. 补Wang2021原始提取/换算记录，确认当前kg/m³数字的来源；不能从论文比例反推并宣称未用假设密度。',
        '4. 继续寻找Chaikasatsin抗压尺寸的直接依据，并审核干硬性顶管配方是否符合研究范围。',
        '5. 两份历史Excel仍未提供，710与696条水下记录的差额尚未解决。','',
        '本轮不写入人工最终决策，不改变0条“已核实可用”的现状。无需现在上传所有其他论文。']
(ROOT/'report.md').write_text('\n'.join(lines)+'\n')
# 所有已有输入的哈希与上次审计记录核对，再核对新PDF下载后的指纹。
old=json.loads((ROOT.parent/'final-audit/manifest.json').read_text())['inputs_sha256']
checks=[]
for path,digest in list(old.items())+[(p['path'],p['sha256']) for p in papers]:
 actual=hashlib.sha256(Path(path).read_bytes()).hexdigest()
 assert actual==digest,path
 checks.append({'path':path,'sha256':actual,'unchanged':True})
assert hashlib.sha256(registry_path.read_bytes()).hexdigest()==registry_before
readback=openpyxl.load_workbook(ROOT/'第一批论文_字段证据核查.xlsx',read_only=True)
assert readback['字段证据核查'].max_row-1==len(findings)==12
assert readback['相关记录索引'].max_row-1==len(links)==236
assert sum(r['初筛候选'] for r in links)==98
readback.close()
(ROOT/'validation.json').write_text(json.dumps({'inputs':checks,'findings':len(findings),
 'linked_records':len(links),'linked_candidates':98,'registry_modified':False,
 'xlsx_readback_passed':True,'models_trained':False,'created_at_utc':datetime.now(timezone.utc).isoformat()},ensure_ascii=False,indent=2))
print('12项字段证据；236条相关记录，其中98条初筛候选；Excel回读通过；7份输入哈希未变。')
