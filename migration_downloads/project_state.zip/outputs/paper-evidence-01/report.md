# 第一批论文证据核查

本次只核查此前列出的关键问题，未修改原始Excel/PDF、可靠状态主档或候选资格；未训练模型。
PDF页码从文件第一页起计。字段级证据不等于整条样本已核实；以下结论尚待用户或老师审阅。

## 实际关联范围

|论文|当前主表相关记录|其中初筛候选|
|---|---:|---:|
|Sonebi|180|84|
|Wang|19|0|
|Chaikasatsin|9|0|
|Brzozowski|6|3|
|Yousri|22|11|

以上是当前档案的实际记录数，包含空气对照及候选外记录，不是新增可信数量。
文件名中的(1)单独保留，未重命名原文件；关联是来源身份对应，不能证明与历史提取时PDF字节完全一致。

## 主要核查结果

### E01 Sonebi：试件及减水剂信息

位置：PDF第3页，Materials；Mixing and test methods。
原文摘录：100 x 200 mm cylinders；melamine HRWR: 1.20 specific gravity；naphthalene HRWR: 1.21 specific gravity
可确认：可确认文中圆柱100×200 mm，减水剂按类型报告不同相对密度。
未解决：这些值不能移用于缓凝剂、纤维素AWA或混凝土整体；各记录外加剂类型仍需对应。
建议：Cy100有原文支持；本轮未逐条复核强度及0.95换算系数来源。

### E02 Sonebi：缓凝剂及配合比

位置：PDF第4页，Table 1；Mixing and test methods续。
原文摘录：Set retarder, mL/100 kg of cementitious materials: 85；主材料用量以kg/m³列出
可确认：85是每100 kg胶材的缓凝剂体积，不是kg/m³；不能把现有0当作未掺。
未解决：所查材料及配合比段落未找到可直接用于缓凝剂质量换算的产品密度。
建议：保留原值；在核查表标记缓凝剂质量未知，主材料表格值不等于整条特征已完整。

### E03 Yousri：HRWR单位与特殊配方

位置：PDF第3页，Table 2；Experimental programme续。
原文摘录：HRWR l/m³: 2.1 / 2.5；M–10FA–VA中HRWR为横线；viscosity agent为0.6%
可确认：减水剂表格单位为L/m³；M–10FA–VA不能套用2.5。
未解决：同页正文写0.35～0.42% by mass of cement，与逐行表格的单位及基准关系需要解释；本轮未获得可靠产品密度。
建议：先逐配方核对，禁止把体积数字直接当质量；特殊配方独立处理。

### E04 Yousri：试件及养护

位置：PDF第3页，Experimental programme续。
原文摘录：Twelve 150 mm cubes；cubes filled under water；tested at 3, 7 and 28 days
可确认：150 mm立方体及水下/空气对照有明确说明。
未解决：本轮未逐条复核28d强度提取精度、零值和换算适用依据。
建议：Cu150有原文支持，但整条可靠状态继续待核查。

### E05 Wang：绝对用量来源

位置：PDF第3页，§2.2；Table 3。
原文摘录：water:binder=0.48；cement:sand:stone=1:1.8:2.3；UWB-II=1/40 of cement；Table 3: mass ratio
可确认：表3给质量比例，所查段落未提供足以唯一还原各配方kg/m³的统一基准。
未解决：是否在原始提取过程中借助了假设密度仍未知；原文材料密度不能自动视为混凝土体积基准。
建议：19条继续暂不纳入候选；不能宣称已证明使用或未使用密度假设。

### E06 Wang：浇筑与试件

位置：PDF第4页，Fig.4；§2.3续；§2.4.2。
原文摘录：Fig.4: forming ... samples for compression testing；100 mm × 100 mm × 100 mm cubic molds
可确认：图4给出水中灌注示意，正文明确100 mm立方体。
未解决：需继续核对各样本目标读数、配比绝对用量及统一换算依据。
建议：水下成型有图示支持，但不得据此恢复19条为可信样本。

### E07 Brzozowski：正文密度信息与试件

位置：PDF第2页，§2.1；§2.2.1。
原文摘录：superplasticizer ... specific weight of 1.16 kg/m³ ... 2% of cement mass；100 mm cubes
可确认：原文确有减水剂specific weight数值，不能再简单记为“完全未报告密度”；单位按印刷原文为kg/m³。
未解决：印刷单位异常；不能擅自改成kg/L。正文2%×429=8.58 kg/m³，不能直接与表1的12 L/m³等同。
建议：标为原文单位/掺量冲突；100 mm切割立方体有原文支持。

### E08 Brzozowski：SP及乳液体积

位置：PDF第3页，Table 1。
原文摘录：UCR1/UCR2 superplasticizer=12.0 L/m³；UCR3=6.0 L/m³；UCR3 styrene-acrylic co-polymer=5 L/m³
可确认：表1明确减水剂及乳液为体积用量。
未解决：正文异常单位和质量百分比与表格冲突未解决；未找到乳液可靠质量换算依据。
建议：保留SP和乳液原值待核；不直接录为12、6、5 kg/m³。

### E09 Chaikasatsin：静态离析试件

位置：PDF第53页，§4.2.3.3；Fig.4.2（印刷页38）。
原文摘录：Cast concrete cylinder specimens (150 x 300 mm) and split ...
可确认：150×300 mm在静态离析试验中出现。
未解决：不能自动挪用为抗压试件尺寸。
建议：505～510行的默认Cy150不能写成论文已明确报告的抗压尺寸。

### E10 Chaikasatsin：抗压方法

位置：PDF第54页，§4.2.3.5（印刷页39）。
原文摘录：Compressive strength ... ASTM C39；specimens both underwater and in the air；7, 14, 28 days
可确认：抗压章节说明ASTM C39、环境对照及龄期。
未解决：该段没有给对应抗压圆柱直径和高度。
建议：规格依据继续待核查；标准名称不能代替尺寸证据。

### E11 Chaikasatsin：最终修补配方

位置：PDF第60页，Table 4.3（印刷页45）；PDF p50 §4.1。
原文摘录：w/b=0.40；Sp/b=2.5%；VMA/w=7%；rfa=10%；Exp.=30 kg；p50正文为30 kg/m³ expansive agent
可确认：配比表给出比例、掺量及单位说明；正文另支持膨胀剂30 kg/m³。
未解决：表4.3仍未直接列出该最终配方所有组分完整kg/m³；不能凭比例填补其余零值。
建议：509～510行逐字段待核，避免把全部0解释成未添加。

### E12 Chaikasatsin：顶管干硬性混凝土

位置：PDF第72页，Table 5.1；§5.3.1.1（印刷页57）。
原文摘录：dry-cast concrete for jacking pipe；Gravel 356+830 kg/m³；SP 3140/3100 mL/m³
可确认：表格属于顶管干硬性混凝土，且减水剂另用mL/m³。
未解决：511～513行是否符合本阶段水下浇筑范围需要重新核对；强度与规格尚未逐条解决。
建议：不能仅因论文含水下混凝土章节就将该章配方视作水下浇筑；本轮不删除记录。

## 下一步

1. 审阅Excel“字段证据核查”页，尤其Brzozowski正文specific weight单位与表格冲突。
2. 有条件时补Yousri的减水剂和Sonebi缓凝剂产品资料，优先寻找对应产品、年代、密度和剂量基准。没有资料继续未知。
3. 补Wang2021原始提取/换算记录，确认当前kg/m³数字的来源；不能从论文比例反推并宣称未用假设密度。
4. 继续寻找Chaikasatsin抗压尺寸的直接依据，并审核干硬性顶管配方是否符合研究范围。
5. 两份历史Excel仍未提供，710与696条水下记录的差额尚未解决。

本轮不写入人工最终决策，不改变0条“已核实可用”的现状。无需现在上传所有其他论文。
