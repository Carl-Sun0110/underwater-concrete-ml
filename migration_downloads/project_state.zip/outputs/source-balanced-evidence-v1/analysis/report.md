# 来源等权选参与文献输入版本对照

同一283条AB开发记录、20个来源连通组和五个外层折。113项测试通过，16组实验、4528条折外预测。
旧版原字段+等权折选参精确复现上轮RF/XGBoost每条折外预测，最大差异0；其他比较采用同一参数范围。

|模型|版本|内层选参|MAE MPa|RMSE MPa|R²|来源组平均MAE|
|---|---|---|---:|---:|---:|---:|
|rf|recorded|fold_mean|6.862|10.156|0.224|10.837|
|rf|recorded|source_macro|6.862|10.156|0.224|10.837|
|xgb|recorded|fold_mean|5.892|8.740|0.425|9.357|
|xgb|recorded|source_macro|5.604|8.755|0.423|9.399|
|rf|unit_mask|fold_mean|9.619|14.922|-0.675|13.898|
|rf|unit_mask|source_macro|8.280|12.406|-0.158|12.922|
|xgb|unit_mask|fold_mean|7.695|12.927|-0.257|12.911|
|xgb|unit_mask|source_macro|7.681|12.781|-0.229|13.150|
|rf|recorded_plus_source_ratios|fold_mean|6.524|9.147|0.371|9.717|
|rf|recorded_plus_source_ratios|source_macro|6.597|9.165|0.368|9.727|
|xgb|recorded_plus_source_ratios|fold_mean|5.755|9.071|0.381|9.943|
|xgb|recorded_plus_source_ratios|source_macro|5.540|8.834|0.413|9.566|
|rf|unit_mask_plus_source_ratios|fold_mean|7.483|10.921|0.103|10.581|
|rf|unit_mask_plus_source_ratios|source_macro|8.011|11.778|-0.043|11.939|
|xgb|unit_mask_plus_source_ratios|fold_mean|7.492|12.876|-0.247|11.837|
|xgb|unit_mask_plus_source_ratios|source_macro|7.435|12.691|-0.211|12.013|

结果解释：
- 样本平均MAE最低：xgb__recorded_plus_source_ratios__source_macro，MAE5.5399、RMSE8.8340 MPa、R²0.4131，来源宏平均MAE9.5664。
- 来源宏平均MAE最低：xgb__recorded__fold_mean，宏平均9.3572，样本MAE5.8924。来源等权内层选参并未保证外层来源等权误差改善。
- 此前参考XGBoost：MAE5.7187、RMSE8.6963、R²0.4312，来源宏平均MAE9.4956。新候选只改善部分指标，保留为探索候选而不宣布统一最优。
- 输入单位敏感性版在18条记录的38个单元格设置未知，全部样本与标签保留；主要是Zhang绝对用量依据未知24项及Yousri/Brzozowski体积水量14项。原版本数值未覆盖。
- 原字段有12列；来源比值版本增加6列。两套字段都各自比较有/无单位处理，分开识别缺失信息增加和新特征的效果。比值仅用同单位/同基准数值，不用未知密度反算。
- 未知值增多后的误差上升反映信息损失和插补影响，不等于证明原始推算质量用量正确；本轮没有新测量绝对用量，不能将此称为完整质量改进。
- 来源特征仅覆盖部分论文：定义中的分项未知仍保留；Al-Selmi分项1503与注释1502冲突不被算术消除。缺失模式可能反映证据覆盖，未使用论文ID作模型输入。

后续建议：停止在同一开发集上连续按最低分扩展参数网格；优先获得高影响来源的真实配合比单位和绝对/相对基准，新增有依据的数据版本后再做同折对照。独立科研结论需另行预先固定验证方案。
当前训练模型仍可作为探索工具运行；不等待全部文献或全部字段核实完毕。

修改/新增文件：configs/source_balanced_evidence_v1.json、src/concrete_audit/source_weighting.py、scripts/run_source_weighting.py、scripts/summarize_source_weighting.py、tests/test_source_weighting.py、README.md。
函数解释：source_ratios读取原文同单位比例；versioned_inputs只生成新矩阵和逐格变更记录；selection_scores分开折、来源、样本三种权重；paired_search复用内层预测选择两个目标；run锁定外层验证并保存配对差异。
