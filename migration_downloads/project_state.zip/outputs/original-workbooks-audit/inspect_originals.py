"""只读对比用户新提供原版、批注版及筛选候选表，不改状态。"""
from pathlib import Path
from collections import Counter
import hashlib,json
import openpyxl

OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/attachments')
paths={
 'total':next((ROOT/'22c7b11d-170d-42eb-97c6-2593982771b2').glob('*.xlsx')),
 'selected':next((ROOT/'f8f19a54-f61c-427e-bc8f-48e8661b2212').glob('*.xlsx')),
 'annotated':next((ROOT/'c841de1c-56a6-40b4-91f2-b1c87ed10763').glob('*.xlsx')),
 'screening':next((ROOT/'6795da7a-5ba2-4f35-ab02-92c656f37857').glob('*.xlsx'))}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={k:sha(p) for k,p in paths.items()}
books={k:openpyxl.load_workbook(p,data_only=False) for k,p in paths.items()}
def records(w):
 s=w['Data'];params={int(r[0])+1:r[3] for r in w['Parameter Explanation'].iter_rows(min_row=2,values_only=True) if isinstance(r[0],int) and r[3]}
 merged={}
 for a in s.merged_cells.ranges:
  if a.min_col==a.max_col and a.min_col in (1,2):
   for row in range(a.min_row,a.max_row+1):merged[row,a.min_col]=s.cell(a.min_row,a.min_col).value
 return {row[0].row:{params[c.column]:merged.get((c.row,c.column),c.value) for c in row if c.column in params}
         for row in s.iter_rows(min_row=7) if any(c.value is not None for c in row)}
D={k:records(books[k]) for k in ('total','selected','annotated')}
summaries={}
for key in D:
 w=books[key];r=D[key]
 summaries[key]={'path':str(paths[key]),'sha256':before[key], 'records':len(r),
  'fields':len(next(iter(r.values()))),'casting_env':dict(Counter(x.get('CastingEnv') for x in r.values())),
  'sheets':[{ 'name':s.title,'rows':s.max_row,'columns':s.max_column} for s in w],
  'strength_fields':[x for x in next(iter(r.values())) if 'CS_28d' in x or 'Conversion' in x],
  'zero_cs28d':sum(x.get('CS_28d')==0 for x in r.values())}
changes=[];identity_errors=[]
for row,a in D['total'].items():
 b=D['annotated'].get(row,{})
 for field in ('PDF filename','Research Group','Specimen ID'):
  if a.get(field)!=b.get(field):identity_errors.append({'row':row,'field':field,'total':a.get(field),'annotated':b.get(field)})
 for field in a.keys()|b.keys():
  if a.get(field)!=b.get(field):changes.append({'row':row,'field':field,'total':a.get(field),'annotated':b.get(field)})
sel_identity=[];env_mismatches=[];cs_mismatches=[]
for row,a in D['total'].items():
 b=D['selected'].get(row,{})
 for field in ('PDF filename','Research Group','Specimen ID'):
  if a.get(field)!=b.get(field):sel_identity.append({'row':row,'field':field,'total':a.get(field),'selected':b.get(field)})
 if {1:'Underwater',2:'Air'}.get(b.get('CastingEnv'))!=a.get('CastingEnv'):
  env_mismatches.append(row)
 if a.get('CS_28d')!=b.get('CS_28d'):
  cs_mismatches.append({'row':row,'total':a.get('CS_28d'),'selected':b.get('CS_28d')})
headers=next(books['screening']['初筛候选527'].values)
candidates=[dict(zip(headers,row)) for row in list(books['screening']['初筛候选527'].values)[1:]]
cand_diffs=[]
for c in candidates:
 row=c['原表行号']; a=D['total'].get(row,{})
 for field in c.keys()&a.keys():
  if c[field]!=a[field]:cand_diffs.append({'row':row,'field':field,'total':a[field],'candidate':c[field]})
result={'workbooks':summaries,'total_annotated_identity_errors':identity_errors,
 'total_annotated_changes':len(changes),'changes_by_field':dict(Counter(x['field'] for x in changes)),
 'casting_changes':[x for x in changes if x['field']=='CastingEnv'],
 'selected_identity_errors':sel_identity,'selected_environment_mismatch_rows':env_mismatches,
 'selected_cs28d_changes':len(cs_mismatches),'selected_cs28d_examples':cs_mismatches[:12],
 'candidate_total_field_differences':len(cand_diffs),'candidate_total_difference_examples':cand_diffs[:12],
 'input_hashes_unchanged':all(sha(p)==before[k] for k,p in paths.items())}
assert result['input_hashes_unchanged']
for name,obj in [('summary.json',result),('total_annotated_changes.json',changes),('candidate_total_changes.json',cand_diffs),
                 ('selected_cs28d_changes.json',cs_mismatches),
                 ('encoding_rules.json',list(books['selected']['Non-Numerical Treatment'].values))]:
 (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str))
print(json.dumps({k:v for k,v in result.items() if k not in ('workbooks','total_annotated_identity_errors','selected_identity_errors','selected_cs28d_examples','candidate_total_difference_examples')},ensure_ascii=False,indent=2,default=str))
for w in books.values():w.close()
