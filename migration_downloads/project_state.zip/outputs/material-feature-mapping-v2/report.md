# 材料语义与证据覆盖报告

范围：现有458条暂定标签探索记录；字段声明涉及5篇原文，不宣称已穷尽其他原文。
所有候选值均待人工确认，不提升整条可信状态、不加入模型。空值为未知，CSV空白不是0。

|候选字段|单位/基准|有证据候选/458|训练部分候选/299|
|---|---|---:|---:|
|material_system|category / 材料体系|10|10|
|antiwashout_product|category / 产品/聚合物名称，不表示产品等效|107|23|
|fiber_type|category / 本轮已定位的纤维种类，不推断其他纤维不存在|11|11|
|polymer_pct_cement|% / cement_mass|4|4|
|awa_pct_binder|% / binder_mass|63|6|
|awa_mass_kg_m3|kg/m3 / mixture_volume|9|9|
|steel_mass_ratio_cement|kg/kg / cement_mass|4|4|
|pva_vol_pct|% / mixture_volume|6|6|
|pva_mass_kg_m3|kg/m3 / mixture_volume|6|6|
|pva_density_kg_m3|kg/m3 / fiber_volume|6|6|
|awa_pct_cement|% / cement_mass|10|10|
|awa_volume_L_per_100kg_binder|L/100kg / binder_mass|27|0|
|pp_mass_kg_m3|kg/m3 / mixture_volume|1|1|
|sp_volume_L_m3|L/m3 / mixture_volume|97|13|
|retarder_mL_per_100kg_binder|mL/100kg / binder_mass|84|0|
|copolymer_volume_L_m3|L/m3 / mixture_volume|1|1|
|viscosity_modifier_pct_cement|% / cement_mass|1|1|

零值只按明确未掺证据或完整来源表中的明确剂量0逐配方保存；其他未编录记录保留未知。
Zhang绝对kg/m³基准仍未知，按水泥比例保存，不借此生成绝对用量。
Al-Selmi PVA体积百分比与质量分开：1.5/100×1280=19.2、1.75/100×1280=22.4 kg/m³。
PVA密度1.28 g/cm³来自p5 Table3，换算1280 kg/m³；不是假定混凝土密度。
Al-Selmi胶材表注1502与分项1202+301=1503的矛盾保留；不由AWA百分比重算或覆盖表4质量。
不同产品和基准不合并。材料体系标签可能代理来源，未来需按来源分组验证，不能用论文ID代替材料特征。
本轮测试部分只统计输入覆盖，未读取目标进行选择或重新评价。
下一步先扩展既有论文中的同类字段证据，并确定共同可用特征，再另建训练配置；当前覆盖不足以直接加入全部模型。

本轮扩展Sonebi、Yousri、Brzozowski；Wang2021和Chaikasatsin在当前458条中没有记录，未恢复入集。
Sonebi表3/4中的control None仅对应3条指定控制配方；不是把所有AWA=0当未掺。
Sonebi液态纤维素AWA按L/100kg胶材保存；缓凝剂85mL/100kg胶材不转换成kg/m³。
Yousri VA单独建列，不将VA当成welan-gum AWA或把横线当零；百分比基准为水泥质量。
Brzozowski表1的SP和乳液按L/m³保留，PP纤维仅UCR2报告0.9kg/m³；异常印刷密度不采用。
未对未编录来源默认标为普通混凝土，也未把同篇论文的标签自动传播到其他来源。
