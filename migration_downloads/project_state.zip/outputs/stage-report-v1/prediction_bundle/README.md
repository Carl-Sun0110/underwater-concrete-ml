# 探索性配合比CSV预测包

此包冻结Baseline V1.1扩展训练320条拟合的Water/Cem中位数XGBoost。它不是正式科研或工程验证模型。当前训练分组CV R²约0.084；未加入待核查Cem0假设。

在本目录、Python 3.12环境运行：

```bash
python -m pip install -r requirements-baseline-v1.txt
PYTHONPATH=src python scripts/predict_strength.py --model model.joblib --input example_inputs.csv --output your_predictions.csv
```

输入列case_id,Water,Cem；值须与原库名义配合比单位一致，不能自动把体积转换成质量。0/负数/空值依旧标为未知。结果包含缺失、超训练单变量范围和探索状态；范围内也不能证明可靠，不提供置信区间。

example_inputs.csv来自现有训练样本，只是程序演示；predictions_from_package_test.csv是打包后实际运行结果，不能当独立测试。输出文件必须不存在。
