# 模块1与模块2审计报告

本报告仅审计及管理可靠状态；未预处理、未训练模型。

## 运行结果

```json
{
  "raw_records": 1082,
  "raw_unique_pdf_sources": 54,
  "historical_underwater_reported": 696,
  "underwater_count_matches_historical": false,
  "casting_env_counts": {
    "Air": 372,
    "Underwater": 710
  },
  "candidate_records_in_screening": 527,
  "candidate_status_counts": {
    "待核查": 527
  },
  "candidate_field_differences": 0,
  "matched_candidate_records": 527,
  "review_records_in_screening": 437,
  "status_counts": {
    "待核查": 710,
    "已核实可用": 0,
    "已排除": 372
  },
  "comments": 51,
  "cross_version_field_differences": 37,
  "identity_mismatch_links": 0,
  "orphan_source_rows": [],
  "completeness_all_match": true,
  "inputs_unchanged": true,
  "missing_files_or_evidence": [
    "水下混凝土_人工核查版.xlsx（未提供同名版本；不认定批注版与其等同）",
    "水下混凝土_筛选结果_20261012.xlsx（目前只有其衍生汇总）",
    "来源论文PDF及页码/表格/图像证据",
    "完整强度换算依据及适用条件",
    "逐条密度假设、单位和零值语义的人工核查决策档案"
  ]
}
```

## 版本差异与待补文件

批注版实际计数为水下710条；历史统计为696条。缺少历史原表，不能定位或解释全部差额。
候选身份成功关联527条；候选共享字段差异0项。
跨版本差异按字段计数：{'CA': 12, 'Cem': 12, 'RS': 12, 'CS_Spec': 1}；逐项见version_differences.json，未覆盖任一版本。
54个主表PDF文件名仅为来源引用，文件提供情况见evidence_inventory.json；程序未独立核实论文内容。
- 水下混凝土_人工核查版.xlsx（未提供同名版本；不认定批注版与其等同）
- 水下混凝土_筛选结果_20261012.xlsx（目前只有其衍生汇总）
- 来源论文PDF及页码/表格/图像证据
- 完整强度换算依据及适用条件
- 逐条密度假设、单位和零值语义的人工核查决策档案

## 解释与限制

注意：批注版当前水下/空气计数与历史汇总可能不同，请查看summary.json，不能据此覆盖历史版本。
已核实可用=0表示本次没有提供通过证据门槛的整条人工核查决策，不表示没有潜在可用数据。
已排除仅表示原表明确为Air而不在本研究范围；历史排除状态保留，未自动升级为当前最终结论。
批注是附件中的核查陈述，并非本程序亲自查阅论文的结果；即使写有“已核对”也不自动授予整条可信资格。
批注只关联锚点及明确A1:B2形式的行范围；其余自然语言范围及字段适用性需人工确认。
仅展开原有身份合并单元格，其他空白保持未知；跨版本先核对三项身份，再保留差异，不覆盖数据。
机械换算一致不代表换算系数有可靠依据；零值未填补，Density未据正负判定来源。
缺少的同名原始文件不能由批注版或衍生工作簿自动替代；尚不能完整重现历史筛选流程。

## 输出索引

- registry.json：逐条来源、状态、未知项、机械结果、待核查原因和处理历史。
- comments.json / cell_styles.json：批注全文、位置及原始格式线索。
- version_differences.json / links.json：跨版本字段差异与身份关联检查。
- completeness.json：特征完整性逐项复算。
- workbook_structure.json / parameter_dictionary.json：结构与单位字典。
- manifest.json：输入路径、内容哈希、代码指纹及运行环境。

下一步：先审核版本差异和批注，补充论文证据与人工决策；确认后再进入预处理。
