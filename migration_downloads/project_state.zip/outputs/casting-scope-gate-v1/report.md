# 水下浇筑范围门禁与后续训练预案

458条暂定标签记录中：212条有直接水下浇筑方法证据但仍待人工确认，216条范围未知，30条Assaad处理后重装模实验独立隔离。这里的范围判断不等于强度换算、绝对用量或整条可靠性已通过。

|视图|记录总数|原训练部分|来源组|原测试部分中范围符合数（仅审计）|
|---|---:|---:|---:|---:|
|严格方法证据范围|212|128|5|84|
|仅隔离已知30条（仍含未知范围）|428|269|19|145|

原145条测试ID完整保留，61条在严格范围内尚无方法证据；没有将它们移入训练，也没有测试预测或重新评价。14条核心输入未知记录仍保留在审计总体，不因门禁自动填补或投入训练。

## 范围证据与处理

Sonebi84条、Yousri11条、Brzozowski3条通过已编录完整配方ID与原文水下成型方法绑定；Zhang4条、Al-Selmi6条和Nasr104条沿用逐配方方法证据。Assaad30条的冲洗/渗水后重装模证据独立保存。不凭Underwater标签、题名、零值或算术一致认定可靠。

未知216条不会进入严格视图；在“仅隔离”视图中会保留，但必须明确称为混合未知范围的探索分析。两种视图均未改变原始文件、可靠状态或历史训练/测试划分。

## 交叉验证检查

严格视图保留旧折后的验证样本数为{'1': 104, '2': 4, '3': 11, '4': 9, '5': 0}，第5折为空，禁止直接沿用旧折。已仅用分组标签重建5外折×4内折的可执行预案；占位X/y均为0，没有用真实目标决定分组。

严格训练仅5个组，组大小为11、3、104、4、6，Nasr两篇保持同一防泄漏组；最大组104/128=81.25%。外层最少训练24条，内层最少训练13条。能运行不代表泛化结论稳定，应报告各来源误差和折间波动，不能只报最高R²。

仅隔离视图269条/19组单独建立相同规则的CV预案。不同视图样本不同，不能直接比较分数后宣称数据筛选带来提升；同一视图的各算法必须使用相同折。

## 后续训练预案（未启用）

保留均值、岭回归基线，比较SVR、随机森林、XGBoost、带Dropout的MLP。输入暂维持Water/Cem及计算比值两种表示，未知材料字段不填0加入模型；所有缩放和调参留在训练折内，沿用既有预定网格及MAE选择指标。

两个planned配置均为`training_execution_authorized=false`；实际训练入口会在拟合前拒绝执行。新训练必须提供范围档案路径、模式和版本指纹。旧比较配置缺少范围门禁会报错；如确需复现历史方案，必须在新副本显式设置`historical_scope_reproduction_only=true`，不能把复现当成新严格结果。旧基线入口同样仅保留显式历史复现用途。

历史测试集曾用于基线评价，本轮没有重评；未来严格模型仍需独立外部来源或前瞻数据验证，不通过重新随机划分来伪称全新未见测试。

## 输出及复现

- `浇筑范围审查与隔离清单.xlsx`：458条范围状态、30条隔离清单、216条未知范围。
- `scope_registry.json`：逐条证据档案，身份和上游文件版本绑定。
- `scope_views.json`：两种范围清单和原145条测试ID。
- `training_plan.json`：CV样本归属、组隔离及两份未启用的训练配置。

```bash
python scripts/prepare_scope_evidence.py
python scripts/run_scope_gate.py --output outputs/new-scope-gate
python scripts/plan_scope_training.py --folder outputs/new-scope-gate
PYTHONPATH=src /workspace/.venv-underwater-ml/bin/python -m unittest discover -s tests -v
```

新可信样本0；本轮没有训练。剩余问题是范围未知216条、严格训练来源仅5组，以及原有换算/掺量疑点尚未全部解决。

## 实跑验证与修改清单

完整72项测试通过，日志见tests.log；独立Excel已重新打开核对458/30/216条。两个真实入口调用均按预期在输出目录创建前停止，见entry_guard_checks.json。原文、标签、原可靠状态与划分的输入指纹再次校验一致。

新增scope_gate.py、test_scope_gate.py、prepare_scope_evidence.py、run_scope_gate.py、plan_scope_training.py及casting_scope_evidence.json；修改train_compare.py、baselines.py以落实范围/历史复现检查，更新README和CHANGELOG。
