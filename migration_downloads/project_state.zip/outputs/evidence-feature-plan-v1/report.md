# 新增证据特征与预处理检查

本轮新增细骨料/水泥质量比候选，原文证据覆盖严格范围128条训练记录、5个来源组。不是仅对原有Water/Cem重新组合，而是引入原文细骨料配比信息。所有候选仍待人工确认，没有改变整条可靠状态。

Zhang以归一化Sand/Cement=1.05直接取得；其他来源以同表kg/m³细骨料与水泥相除。分母是水泥，不是胶凝材料。Yousri的F.A.是细骨料，不是FA粉煤灰；Brzozowski没有使用相邻Water/SP体积列。无需假定混凝土密度，也不据此宣称Zhang原库绝对kg/m³已验证。

实际执行5次外折预处理：只在外训练折拟合StandardScaler，验证折仅transform，未接收目标y。没有填补未知值，没有回归模型训练，也未读取测试行用于预处理。该缩放审计不等同于未来内折缩放；未来调参必须在每个内训练折重新拟合。

|其他候选字段|有值/128|来源组/5|仅验证折有证据的外折|
|---|---:|---:|---|
|water_environment|104|1|1|
|water_motion_condition|104|1|1|
|water_velocity_m_s|64|1|1|
|material_system|114|3|无|
|upa_reported_percent_water_medium|104|1|1|
|sp_volume_L_per_100kg_cement|104|1|1|
|awa_mass_kg_m3|9|2|无|
|polymer_pct_cement|4|1|4|
|pva_vol_pct|6|1|3|

水环境、流速、UPA浓度等看似覆盖较高，实际集中在Nasr同一组；该组被留出时，训练折没有此列原文证据。不能利用被留出的数据决定填补值或编码，也不能把未知填0冒充观测。
UPA和SP仍有原文浓度/单位疑点，本轮未因覆盖率较高直接准许入模。材料体系类别也可能与来源混杂，仍需独立处理。

## 下一轮预案

先保持相同128条、相同外折与既有参数网格，只比较加入细骨料质量比前后的训练内折外结果。保留不加计算水灰比和加入计算比值两种表示。其他稀疏/争议列继续独立审计，不混入主比较。
现有模型训练入口只接收Water/Cem，本轮输出是特征准备政策而非可执行训练配置；下一阶段需为证据特征建立独立接入版本，禁止直接改旧文件冒充原方案。

关键函数：positive_table_columns精确读取所需原表列；mass_ratio检查同单位/同归一化基准；build_feature_records只生成固定训练ID的X；EvidenceFeatureTransformer检查三列正数并可计算Water/Cem；fold_support检查来源与外折证据覆盖。

未解决：原核心Water/Cem和暂定强度仍有历史可靠性疑点；新质量比有原文依据但未人工签字，来源仍只有5组。

输出：candidate_training_features.json、evidence_snapshot.json、fold_preprocessing_audit.json、other_feature_fold_support.json和独立Excel。

## 验证与修改清单

完整80项测试通过；Excel重新打开确认128条候选与128项原文证据。所有保护输入内容指纹复核一致，5折预处理没有使用测试行或目标。

新增src/concrete_audit/evidence_features.py、tests/test_evidence_features.py、scripts/prepare_fine_aggregate_ratio.py、scripts/run_evidence_feature_plan.py、configs/fine_aggregate_ratio_evidence.json；更新README.md和CHANGELOG.md。原数据及历史结果不变。
