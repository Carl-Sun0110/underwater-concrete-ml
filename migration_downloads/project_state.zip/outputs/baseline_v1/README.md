本次Baseline V1结果见report.md；Excel为Baseline_V1结果与筛选记录.xlsx；图在plots/，代码副本在code/。
全部结果为探索性，原始数据和历史输出未覆盖。

固定依赖见requirements-baseline-v1.txt；需原始附件路径和仓库src，复现命令见report.md。代码副本用于版本审阅，实际入口为仓库scripts/run_baseline_v1.py。
