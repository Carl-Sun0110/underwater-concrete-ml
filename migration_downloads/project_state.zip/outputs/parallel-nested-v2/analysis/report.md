# 第二轮实施结果与下一步

同一数据版本、283条AB开发记录、五个外层分组折，六组嵌套实验。
本轮最低MAE 5.8924 MPa（xgb__materials__nested）；上轮固定参数参考 5.7187 MPa。未显示整体改善，保留上轮参考。
104项全量测试通过，1698条折外预测，30份外层搜索记录，原始输入哈希、标签、外层折和历史测试隔离均验证通过。

|实验|MAE MPa|RMSE MPa|R²|来源组平均MAE|
|---|---:|---:|---:|---:|
|AB__materials__median__rf__unknown|7.107|10.323|0.198|10.825|
|AB__materials__median__xgb__unknown|5.719|8.696|0.431|9.496|
|rf__materials__nested|6.862|10.156|0.224|10.837|
|xgb__materials__nested|5.892|8.740|0.425|9.357|
|catboost__materials__nested|6.524|10.302|0.202|11.171|
|rf__materials_plus_ratios__nested|6.880|9.685|0.295|9.971|
|xgb__materials_plus_ratios__nested|6.093|9.314|0.348|9.959|
|catboost__materials_plus_ratios__nested|7.241|10.845|0.115|10.967|

解释与决策：
- 本轮XGBoost、CatBoost、RF加入比值后均未改善MAE，不继续无边界叠加特征。RF调参有小幅改善，未超过XGBoost。
- 在已多轮使用的开发集上，调参和挑选实验仍存在适应性偏差；不把当前R²写成最终独立泛化能力。
- 保留全部283条记录和高强度标签。Zhang高强度体系误差仍大，优先改善配合比表示、体系覆盖和单位证据；不能因预测差判定标签错误。
- 已有文献核查档案与折外误差关联在next_review_batch.json，缺失PDF或未知字段仅保留标记，不阻塞其余建模。
- 下一批核查优先处理现有Zhang和Al-Selmi两篇中的配比单位/组分总量依据；模型轨道增加SVR/MLP的同折对照，并考虑来源组等权的内层选参指标。
- 不按论文身份硬编码数值特征，不从待核查信息推导不存在的强度标签。
- 兼容性问题：初次CatBoost 1.2.8缺少sklearn 1.8回归标签接口，已用SklearnCatBoost适配并完成克隆、Pipeline、GridSearch测试；旧失败日志保留。

修改/新增文件：configs/parallel_nested_v1.json（失败配置留档）、configs/parallel_nested_v2.json、src/concrete_audit/nested_exploration.py、scripts/run_nested_exploration.py、scripts/summarize_nested_exploration.py、tests/test_nested_exploration.py、requirements-nested.txt、README.md。
主要函数解释见新模块docstring：derive_ratios处理比值与缺失；tune限定内层调参范围；load_development锁定旧分组；run保存完整嵌套证据；summarize重算指标并生成核查清单。
